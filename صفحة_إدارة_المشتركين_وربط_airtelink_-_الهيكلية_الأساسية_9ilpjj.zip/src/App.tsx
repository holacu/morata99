import { Authenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import AirTelinkSettings from "./pages/AirTelinkSettings";
import SubscribersList from "./pages/SubscribersList";
import NetworkDevices from "./pages/NetworkDevices";
import Dashboard from "./pages/Dashboard";
import InitialSetup from "./pages/InitialSetup";
import { useState } from "react";
import {
  Home,
  Settings,
  Users,
  Wifi,
  Bell,
  Menu,
  X,
  LogOut
} from "lucide-react";

type Page = "setup" | "dashboard" | "subscribers" | "devices" | "settings";

function App() {
  const [page, setPage] = useState<Page>("setup");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const towers = useQuery(api.towers.listTowers);
  
  const toggleMobileMenu = () => setMobileMenuOpen(!mobileMenuOpen);

  // إذا لم يكن هناك أبراج، نعرض صفحة الإعداد الأولي
  if (towers && towers.length === 0) {
    return <InitialSetup />;
  }

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex w-64 flex-col fixed h-full bg-white border-r">
        <div className="p-6">
          <h1 className="text-2xl font-bold">إدارة المشتركين</h1>
        </div>
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => setPage("dashboard")}
                className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                  page === "dashboard" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                }`}
              >
                <Home size={20} />
                <span>لوحة التحكم</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => setPage("subscribers")}
                className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                  page === "subscribers" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                }`}
              >
                <Users size={20} />
                <span>المشتركين</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => setPage("devices")}
                className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                  page === "devices" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                }`}
              >
                <Wifi size={20} />
                <span>الأجهزة</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => setPage("settings")}
                className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                  page === "settings" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                }`}
              >
                <Settings size={20} />
                <span>الإعدادات</span>
              </button>
            </li>
          </ul>
        </nav>
        <div className="p-4 border-t">
          <SignOutButton />
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed w-full bg-white border-b z-50">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-bold">إدارة المشتركين</h1>
          <button onClick={toggleMobileMenu} className="p-2">
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-white border-b">
            <nav className="p-4">
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => {
                      setPage("dashboard");
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                      page === "dashboard" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                    }`}
                  >
                    <Home size={20} />
                    <span>لوحة التحكم</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setPage("subscribers");
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                      page === "subscribers" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                    }`}
                  >
                    <Users size={20} />
                    <span>المشتركين</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setPage("devices");
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                      page === "devices" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                    }`}
                  >
                    <Wifi size={20} />
                    <span>الأجهزة</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setPage("settings");
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                      page === "settings" ? "bg-blue-100 text-blue-600" : "hover:bg-gray-100"
                    }`}
                  >
                    <Settings size={20} />
                    <span>الإعدادات</span>
                  </button>
                </li>
              </ul>
            </nav>
            <div className="p-4 border-t">
              <SignOutButton />
            </div>
          </div>
        )}
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 mt-16 md:mt-0">
        <div className="max-w-7xl mx-auto">
          {page === "dashboard" && <Dashboard />}
          {page === "subscribers" && <SubscribersList />}
          {page === "devices" && <NetworkDevices />}
          {page === "settings" && <AirTelinkSettings />}
        </div>
      </main>
      
      <Toaster />
    </div>
  );
}

export default App;
