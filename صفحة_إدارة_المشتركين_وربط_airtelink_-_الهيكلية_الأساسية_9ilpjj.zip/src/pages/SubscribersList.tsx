import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Users, Search, AlertTriangle, Phone, MapPin, Package, Wifi, Plus, X } from "lucide-react";
import { useState } from "react";
import { Id } from "../../convex/_generated/dataModel";

type Subscriber = {
  _id: Id<"subscribers">;
  name: string;
  phone: string;
  address?: string;
  package: string;
  status: "active" | "inactive";
  debt: number;
  earthlinkId: string;
  deviceId?: Id<"network_devices">;
  expiryDate?: number;
};

type DeviceFormData = {
  name: string;
  type: "nanostation" | "mikrotik" | "other";
  model: string;
  ipAddress: string;
  location?: string;
  settings: {
    username: string;
    password: string;
    ssid?: string;
    channel?: number;
    frequency?: string;
  };
};

export default function SubscribersList() {
  const subscribers = useQuery(api.airtelink.listSubscribers, {}) || [];
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [selectedSubscriber, setSelectedSubscriber] = useState<Subscriber | null>(null);
  const [showDeviceForm, setShowDeviceForm] = useState(false);

  const filtered = subscribers.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.phone.includes(search) ||
      s.earthlinkId.includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Users className="text-blue-500" />
          قائمة المشتركين
        </h2>
        
        <div className="flex items-center gap-4">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="بحث بالاسم أو الهاتف..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2">
            <button
              className={`p-2 rounded ${view === 'grid' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100'}`}
              onClick={() => setView('grid')}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            </button>
            <button
              className={`p-2 rounded ${view === 'list' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100'}`}
              onClick={() => setView('list')}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <AlertTriangle className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-900">لا يوجد مشتركين</h3>
          <p className="text-gray-500">لم يتم العثور على أي مشترك يطابق معايير البحث</p>
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((subscriber) => (
            <SubscriberCard 
              key={subscriber._id} 
              subscriber={subscriber as Subscriber} 
              onDeviceClick={() => {
                setSelectedSubscriber(subscriber as Subscriber);
                setShowDeviceForm(true);
              }}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المشترك
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  معلومات الاتصال
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الباقة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الدين
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الجهاز
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filtered.map((subscriber) => (
                <tr key={subscriber._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        {subscriber.name[0]}
                      </div>
                      <div className="mr-4">
                        <div className="text-sm font-medium text-gray-900">{subscriber.name}</div>
                        <div className="text-sm text-gray-500">{subscriber.earthlinkId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{subscriber.phone}</div>
                    <div className="text-sm text-gray-500">{subscriber.address}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{subscriber.package}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      subscriber.status === 'active'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {subscriber.status === 'active' ? 'نشط' : 'غير نشط'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {subscriber.debt > 0 ? (
                      <span className="text-red-600">{subscriber.debt} د.ع</span>
                    ) : (
                      <span className="text-green-600">0 د.ع</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button
                      onClick={() => {
                        setSelectedSubscriber(subscriber as Subscriber);
                        setShowDeviceForm(true);
                      }}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      {subscriber.deviceId ? 'عرض الجهاز' : 'ربط جهاز'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showDeviceForm && selectedSubscriber && (
        <DeviceFormModal
          subscriber={selectedSubscriber}
          onClose={() => {
            setShowDeviceForm(false);
            setSelectedSubscriber(null);
          }}
        />
      )}
    </div>
  );
}

function SubscriberCard({ subscriber, onDeviceClick }: { subscriber: Subscriber, onDeviceClick: () => void }) {
  const device = useQuery(
    api.network.getDeviceDetails,
    subscriber.deviceId ? { deviceId: subscriber.deviceId } : "skip"
  );

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-semibold text-xl">
          {subscriber.name[0]}
        </div>
        <div>
          <h3 className="font-semibold text-lg">{subscriber.name}</h3>
          <p className="text-gray-500 text-sm">{subscriber.earthlinkId}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 text-gray-600">
          <Phone size={18} />
          <span>{subscriber.phone}</span>
        </div>
        
        {subscriber.address && (
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin size={18} />
            <span>{subscriber.address}</span>
          </div>
        )}
        
        <div className="flex items-center gap-2 text-gray-600">
          <Package size={18} />
          <span>{subscriber.package}</span>
        </div>

        <button
          onClick={onDeviceClick}
          className="w-full mt-2 flex items-center gap-2 p-2 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors"
        >
          <Wifi size={18} />
          {subscriber.deviceId ? (
            <>
              <span>
                {device?.name} - {device?.status === "online" ? "متصل" : device?.status === "warning" ? "تحذير" : "غير متصل"}
              </span>
              {device?.status === "online" && <span className="w-2 h-2 rounded-full bg-green-500 ml-auto" />}
              {device?.status === "warning" && <span className="w-2 h-2 rounded-full bg-yellow-500 ml-auto" />}
              {device?.status === "offline" && <span className="w-2 h-2 rounded-full bg-red-500 ml-auto" />}
            </>
          ) : (
            <>
              <span>ربط جهاز جديد</span>
              <Plus size={18} className="ml-auto" />
            </>
          )}
        </button>
      </div>

      <div className="mt-4 pt-4 border-t flex justify-between items-center">
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
          subscriber.status === 'active'
            ? 'bg-green-100 text-green-800'
            : 'bg-red-100 text-red-800'
        }`}>
          {subscriber.status === 'active' ? 'نشط' : 'غير نشط'}
        </span>

        {subscriber.debt > 0 ? (
          <span className="text-red-600 font-medium">{subscriber.debt} د.ع</span>
        ) : (
          <span className="text-green-600 font-medium">لا يوجد دين</span>
        )}
      </div>
    </div>
  );
}

function DeviceFormModal({ subscriber, onClose }: { subscriber: Subscriber, onClose: () => void }) {
  const linkDevice = useMutation(api.network.linkDeviceToSubscriber);
  const unlinkDevice = useMutation(api.network.unlinkDeviceFromSubscriber);
  const device = useQuery(
    api.network.getDeviceDetails,
    subscriber.deviceId ? { deviceId: subscriber.deviceId } : "skip"
  );
  
  const [formData, setFormData] = useState<DeviceFormData>({
    name: "",
    type: "nanostation",
    model: "",
    ipAddress: "",
    settings: {
      username: "",
      password: "",
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await linkDevice({
      subscriberId: subscriber._id,
      deviceInfo: formData,
    });
    onClose();
  };

  const handleUnlink = async () => {
    if (subscriber.deviceId) {
      await unlinkDevice({
        subscriberId: subscriber._id,
        deviceId: subscriber.deviceId,
      });
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">
            {subscriber.deviceId ? 'تفاصيل الجهاز' : 'ربط جهاز جديد'}
          </h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        {subscriber.deviceId && device ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-500">اسم الجهاز</label>
                <p className="font-medium">{device.name}</p>
              </div>
              <div>
                <label className="text-sm text-gray-500">النوع</label>
                <p className="font-medium">{device.type === "nanostation" ? "NanoStation" : device.type === "mikrotik" ? "Mikrotik" : "آخر"}</p>
              </div>
              <div>
                <label className="text-sm text-gray-500">الموديل</label>
                <p className="font-medium">{device.model}</p>
              </div>
              <div>
                <label className="text-sm text-gray-500">عنوان IP</label>
                <p className="font-medium">{device.ipAddress}</p>
              </div>
              <div>
                <label className="text-sm text-gray-500">الحالة</label>
                <p className={`font-medium ${
                  device.status === "online" ? "text-green-600" :
                  device.status === "warning" ? "text-yellow-600" :
                  "text-red-600"
                }`}>
                  {device.status === "online" ? "متصل" :
                   device.status === "warning" ? "تحذير" :
                   "غير متصل"}
                </p>
              </div>
              {device.location && (
                <div>
                  <label className="text-sm text-gray-500">الموقع</label>
                  <p className="font-medium">{device.location}</p>
                </div>
              )}
            </div>

            <div className="border-t pt-4 mt-4">
              <h4 className="font-medium mb-2">إعدادات الجهاز</h4>
              <div className="grid grid-cols-2 gap-4">
                {device.settings?.ssid && (
                  <div>
                    <label className="text-sm text-gray-500">SSID</label>
                    <p className="font-medium">{device.settings.ssid}</p>
                  </div>
                )}
                {device.settings?.channel && (
                  <div>
                    <label className="text-sm text-gray-500">القناة</label>
                    <p className="font-medium">{device.settings.channel}</p>
                  </div>
                )}
                {device.settings?.frequency && (
                  <div>
                    <label className="text-sm text-gray-500">التردد</label>
                    <p className="font-medium">{device.settings.frequency}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-4">
              <button
                onClick={handleUnlink}
                className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                إلغاء ربط الجهاز
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                إغلاق
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                اسم الجهاز
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                نوع الجهاز
              </label>
              <select
                className="w-full p-2 border rounded-lg"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
              >
                <option value="nanostation">NanoStation</option>
                <option value="mikrotik">Mikrotik</option>
                <option value="other">آخر</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                الموديل
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={formData.model}
                onChange={(e) => setFormData({ ...formData, model: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                عنوان IP
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={formData.ipAddress}
                onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                الموقع (اختياري)
              </label>
              <input
                type="text"
                className="w-full p-2 border rounded-lg"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>

            <div className="border-t pt-4 mt-4">
              <h4 className="font-medium mb-2">معلومات الدخول</h4>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    اسم المستخدم
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full p-2 border rounded-lg"
                    value={formData.settings.username}
                    onChange={(e) => setFormData({
                      ...formData,
                      settings: { ...formData.settings, username: e.target.value }
                    })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    كلمة المرور
                  </label>
                  <input
                    type="password"
                    required
                    className="w-full p-2 border rounded-lg"
                    value={formData.settings.password}
                    onChange={(e) => setFormData({
                      ...formData,
                      settings: { ...formData.settings, password: e.target.value }
                    })}
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg transition-colors"
              >
                ربط الجهاز
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
