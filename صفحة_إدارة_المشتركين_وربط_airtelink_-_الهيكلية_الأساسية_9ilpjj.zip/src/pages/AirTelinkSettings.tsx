import { useMutation, useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState, useEffect } from "react";
import { Loader2, RefreshCcw, Save, CloudDownload } from "lucide-react";
import { Id } from "../../convex/_generated/dataModel";

export default function AirTelinkSettings() {
  const towers = useQuery(api.towers.listTowers);
  const [selectedTowerId, setSelectedTowerId] = useState<Id<"towers"> | null>(null);
  
  useEffect(() => {
    if (towers && towers.length > 0 && !selectedTowerId) {
      setSelectedTowerId(towers[0]._id);
    }
  }, [towers, selectedTowerId]);

  const settings = useQuery(
    api.towers.getEarthlinkSettings,
    selectedTowerId ? { towerId: selectedTowerId } : "skip"
  );
  
  const setupEarthlink = useMutation(api.towers.setupEarthlinkReseller);
  const importSubscribers = useAction(api.towers.importSubscribersFromEarthlink);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [resellerId, setResellerId] = useState("");
  const [loading, setLoading] = useState(false);
  const [importResult, setImportResult] = useState<string | null>(null);

  useEffect(() => {
    if (settings) {
      setUsername(settings.username);
      setPassword(settings.password);
      setResellerId(settings.resellerId);
    }
  }, [settings]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedTowerId) return;
    
    await setupEarthlink({
      towerId: selectedTowerId,
      username,
      password,
      resellerId,
    });
  }

  async function handleImport() {
    if (!selectedTowerId) return;
    
    setLoading(true);
    const result = await importSubscribers({
      towerId: selectedTowerId,
    });
    setImportResult(`تم استيراد ${result.imported} مشترك`);
    setLoading(false);
  }

  if (!towers || towers.length === 0) {
    return (
      <div className="text-center py-12">
        <p>الرجاء إضافة برج أولاً</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto bg-white rounded-xl shadow-lg p-8 mt-8 space-y-6">
      <h2 className="text-2xl font-bold flex items-center gap-2 mb-2">
        <CloudDownload className="text-blue-500" /> إعدادات ربط Earthlink
      </h2>

      <div>
        <label className="font-semibold">
          اختر البرج:
          <select
            className="w-full mt-1 p-2 border rounded-lg"
            value={selectedTowerId || ""}
            onChange={e => setSelectedTowerId(e.target.value as Id<"towers">)}
          >
            {towers.map(tower => (
              <option key={tower._id} value={tower._id}>
                {tower.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      
      <form onSubmit={handleSave} className="flex flex-col gap-4">
        <label className="font-semibold">
          اسم المستخدم:
          <input
            className="w-full mt-1 p-2 border rounded-lg"
            value={username}
            onChange={e => setUsername(e.target.value)}
            required
            placeholder="أدخل اسم المستخدم"
          />
        </label>
        <label className="font-semibold">
          كلمة المرور:
          <input
            type="password"
            className="w-full mt-1 p-2 border rounded-lg"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            placeholder="أدخل كلمة المرور"
          />
        </label>
        <label className="font-semibold">
          معرف الريسيلر:
          <input
            className="w-full mt-1 p-2 border rounded-lg"
            value={resellerId}
            onChange={e => setResellerId(e.target.value)}
            required
            placeholder="مثال: RS123456"
          />
        </label>
        <button
          type="submit"
          className="flex items-center justify-center gap-2 bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Save size={18} /> حفظ الإعدادات
        </button>
      </form>

      <div>
        <button
          className="w-full flex items-center justify-center gap-2 bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors"
          onClick={handleImport}
          disabled={loading || !settings?.isConfigured}
        >
          {loading ? <Loader2 className="animate-spin" size={18} /> : <RefreshCcw size={18} />}
          {loading ? "جاري الاستيراد..." : "استيراد المشتركين"}
        </button>
        {importResult && (
          <div className="mt-4 p-4 bg-green-50 text-green-700 rounded-lg">
            {importResult}
          </div>
        )}
      </div>

      {settings?.lastSync && (
        <div className="text-sm text-gray-500">
          آخر مزامنة: {new Date(settings.lastSync).toLocaleString()}
        </div>
      )}
      {settings?.lastError && (
        <div className="text-sm text-red-500">
          آخر خطأ: {settings.lastError}
        </div>
      )}
      
      <div className="text-xs text-gray-400">
        <b>ملاحظة:</b> يجب عليك الحصول على معلومات الدخول من لوحة تحكم Earthlink الخاصة بك كموزع.
      </div>
    </div>
  );
}
