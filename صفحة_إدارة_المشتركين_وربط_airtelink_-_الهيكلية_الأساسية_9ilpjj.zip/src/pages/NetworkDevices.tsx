import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import {
  Wifi,
  WifiOff,
  Settings,
  AlertTriangle,
  Search,
  RefreshCw
} from "lucide-react";
import { useState } from "react";

type NetworkDevice = {
  _id: string;
  name: string;
  type: "nanostation" | "mikrotik" | "other";
  model: string;
  macAddress: string;
  ipAddress?: string;
  location?: string;
  status: "online" | "offline" | "warning";
  lastSeen?: number;
  settings?: {
    ssid?: string;
    password?: string;
    channel?: number;
    frequency?: string;
  };
};

export default function NetworkDevices() {
  const devices = useQuery(api.network.listDevices) || [];
  const [search, setSearch] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");

  const filtered = devices.filter(
    (d) =>
      (selectedType === "all" || d.type === selectedType) &&
      (d.name.toLowerCase().includes(search.toLowerCase()) ||
        d.macAddress.includes(search) ||
        d.ipAddress?.includes(search))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Wifi className="text-blue-500" />
          أجهزة الشبكة
        </h2>
        
        <div className="flex items-center gap-4">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="بحث عن جهاز..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          
          <select
            className="px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
          >
            <option value="all">جميع الأجهزة</option>
            <option value="nanostation">NanoStation</option>
            <option value="mikrotik">Mikrotik</option>
            <option value="other">أخرى</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <WifiOff className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-900">لا توجد أجهزة</h3>
          <p className="text-gray-500">لم يتم العثور على أي جهاز يطابق معايير البحث</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((device) => (
            <DeviceCard key={device._id} device={device} />
          ))}
        </div>
      )}
    </div>
  );
}

function DeviceCard({ device }: { device: NetworkDevice }) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          {device.status === "online" ? (
            <Wifi className="text-green-500" size={24} />
          ) : device.status === "warning" ? (
            <AlertTriangle className="text-yellow-500" size={24} />
          ) : (
            <WifiOff className="text-red-500" size={24} />
          )}
          <div>
            <h3 className="font-semibold text-lg">{device.name}</h3>
            <p className="text-gray-500 text-sm">{device.model}</p>
          </div>
        </div>
        <button className="p-2 hover:bg-gray-100 rounded-lg">
          <Settings size={20} className="text-gray-500" />
        </button>
      </div>

      <div className="space-y-3 text-sm">
        <div className="flex justify-between items-center">
          <span className="text-gray-500">نوع الجهاز:</span>
          <span className="font-medium">
            {device.type === "nanostation" ? "NanoStation" :
             device.type === "mikrotik" ? "Mikrotik" : "آخر"}
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-gray-500">عنوان MAC:</span>
          <span className="font-mono text-sm">{device.macAddress}</span>
        </div>

        {device.ipAddress && (
          <div className="flex justify-between items-center">
            <span className="text-gray-500">عنوان IP:</span>
            <span className="font-mono text-sm">{device.ipAddress}</span>
          </div>
        )}

        {device.location && (
          <div className="flex justify-between items-center">
            <span className="text-gray-500">الموقع:</span>
            <span>{device.location}</span>
          </div>
        )}

        {device.settings?.ssid && (
          <div className="flex justify-between items-center">
            <span className="text-gray-500">SSID:</span>
            <span>{device.settings.ssid}</span>
          </div>
        )}
      </div>

      <div className="mt-4 pt-4 border-t">
        <div className="flex justify-between items-center">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            device.status === "online"
              ? "bg-green-100 text-green-800"
              : device.status === "warning"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
          }`}>
            {device.status === "online" ? "متصل" :
             device.status === "warning" ? "تحذير" : "غير متصل"}
          </span>
          
          {device.lastSeen && (
            <span className="text-xs text-gray-500">
              آخر ظهور: {new Date(device.lastSeen).toLocaleString("ar-IQ")}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
