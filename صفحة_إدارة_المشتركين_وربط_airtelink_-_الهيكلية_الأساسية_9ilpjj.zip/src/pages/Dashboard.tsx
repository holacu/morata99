import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import {
  Users,
  UserCheck,
  AlertTriangle,
  Wifi,
  WifiOff,
  Bell,
  TrendingUp,
  Calendar
} from "lucide-react";

export default function Dashboard() {
  const towers = useQuery(api.towers.listTowers);
  const subscribers = useQuery(api.airtelink.listSubscribers, {});
  const devices = useQuery(api.network.listDevices);
  const notifications = useQuery(api.notifications.list);

  if (!towers || !subscribers || !devices || !notifications) {
    return (
      <div className="text-center py-12">
        <p>جاري تحميل البيانات...</p>
      </div>
    );
  }

  // إحصائيات المشتركين
  const totalSubscribers = subscribers.length;
  const activeSubscribers = subscribers.filter(s => s.status === "active").length;
  const debtors = subscribers.filter(s => s.debt > 0).length;

  // إحصائيات الأجهزة
  const totalDevices = devices.length;
  const onlineDevices = devices.filter(d => d.status === "online").length;

  // التنبيهات
  const pendingNotifications = notifications.filter(n => n.status === "pending").length;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">لوحة التحكم</h1>
        <p className="text-gray-600">نظرة عامة على نظام إدارة المشتركين</p>
      </header>

      {/* الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="إجمالي المشتركين"
          value={totalSubscribers}
          icon={<Users className="text-blue-500" />}
          trend="+5% من الشهر الماضي"
        />
        <StatCard
          title="المشتركين النشطين"
          value={activeSubscribers}
          icon={<UserCheck className="text-green-500" />}
          trend="92% معدل النشاط"
        />
        <StatCard
          title="المتأخرين عن الدفع"
          value={debtors}
          icon={<AlertTriangle className="text-red-500" />}
          trend="3 حالات جديدة"
        />
        <StatCard
          title="الأجهزة المتصلة"
          value={`${onlineDevices}/${totalDevices}`}
          icon={<Wifi className="text-purple-500" />}
          trend="95% معدل الاتصال"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* آخر التنبيهات */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Bell className="text-yellow-500" />
            آخر التنبيهات
          </h2>
          <div className="space-y-4">
            {notifications.slice(0, 5).map(notification => (
              <div key={notification._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                {notification.type === "subscription_expiry" ? (
                  <Calendar className="text-orange-500" />
                ) : notification.type === "payment_due" ? (
                  <AlertTriangle className="text-red-500" />
                ) : (
                  <WifiOff className="text-gray-500" />
                )}
                <div>
                  <p className="text-sm font-medium">{notification.message}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(notification.createdAt).toLocaleString("ar-IQ")}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* الإحصائيات الشهرية */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="text-green-500" />
            الإحصائيات الشهرية
          </h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>معدل التجديد</span>
              <span className="text-green-500">95%</span>
            </div>
            <div className="flex justify-between items-center">
              <span>معدل الانقطاع</span>
              <span className="text-red-500">3%</span>
            </div>
            <div className="flex justify-between items-center">
              <span>مشتركين جدد</span>
              <span className="text-blue-500">+12</span>
            </div>
            <div className="flex justify-between items-center">
              <span>إجمالي الإيرادات</span>
              <span className="text-green-500">1,234,000 د.ع</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, trend }: {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend: string;
}) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between">
        {icon}
        <span className="text-2xl font-bold">{value}</span>
      </div>
      <h3 className="text-gray-600 mt-2">{title}</h3>
      <p className="text-xs text-gray-500 mt-2">{trend}</p>
    </div>
  );
}
