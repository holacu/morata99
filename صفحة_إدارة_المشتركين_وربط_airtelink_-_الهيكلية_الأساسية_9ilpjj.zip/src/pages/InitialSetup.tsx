import { useState } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { Loader2, Save, CloudDownload, MapPin } from "lucide-react";

export default function InitialSetup() {
  const [step, setStep] = useState<"tower" | "earthlink" | "importing">("tower");
  const [towerId, setTowerId] = useState<Id<"towers"> | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const addTower = useMutation(api.towers.addTower);
  const setupEarthlink = useMutation(api.towers.setupEarthlinkReseller);
  const importSubscribers = useAction(api.towers.importSubscribersFromEarthlink);

  const [towerForm, setTowerForm] = useState({
    name: "",
    location: "",
    description: "",
    coordinates: {
      latitude: "",
      longitude: "",
    },
  });

  const [earthlinkForm, setEarthlinkForm] = useState({
    username: "",
    password: "",
    resellerId: "",
  });

  async function handleTowerSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const id = await addTower({
        name: towerForm.name,
        location: towerForm.location,
        description: towerForm.description || undefined,
        coordinates: towerForm.coordinates.latitude && towerForm.coordinates.longitude
          ? {
              latitude: parseFloat(towerForm.coordinates.latitude),
              longitude: parseFloat(towerForm.coordinates.longitude),
            }
          : undefined,
      });
      setTowerId(id);
      setStep("earthlink");
      setSuccess("تم إضافة البرج بنجاح");
    } catch (err) {
      setError("حدث خطأ أثناء إضافة البرج");
      console.error(err);
    }
    setLoading(false);
  }

  async function handleEarthlinkSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!towerId) return;
    
    setLoading(true);
    setError(null);
    try {
      await setupEarthlink({
        towerId,
        ...earthlinkForm,
      });
      setStep("importing");
      setSuccess("تم ربط حساب Earthlink بنجاح");
      
      // Start importing subscribers
      const result = await importSubscribers({ towerId });
      setSuccess(`تم استيراد ${result.imported} مشترك بنجاح`);
    } catch (err) {
      setError("حدث خطأ أثناء ربط حساب Earthlink");
      console.error(err);
    }
    setLoading(false);
  }

  return (
    <div className="max-w-xl mx-auto bg-white rounded-xl shadow-lg p-8 mt-8">
      <div className="space-y-6">
        {/* Tower Setup */}
        <div className={step !== "tower" ? "hidden" : ""}>
          <h2 className="text-2xl font-bold flex items-center gap-2 mb-6">
            <MapPin className="text-blue-500" />
            إعداد البرج الجديد
          </h2>
          
          <form onSubmit={handleTowerSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                اسم البرج
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={towerForm.name}
                onChange={e => setTowerForm({ ...towerForm, name: e.target.value })}
                placeholder="مثال: برج الكرادة"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                الموقع
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={towerForm.location}
                onChange={e => setTowerForm({ ...towerForm, location: e.target.value })}
                placeholder="مثال: شارع الرشيد - بناية رقم 15"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                وصف البرج (اختياري)
              </label>
              <textarea
                className="w-full p-2 border rounded-lg"
                value={towerForm.description}
                onChange={e => setTowerForm({ ...towerForm, description: e.target.value })}
                placeholder="معلومات إضافية عن البرج..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  خط العرض (اختياري)
                </label>
                <input
                  type="number"
                  step="any"
                  className="w-full p-2 border rounded-lg"
                  value={towerForm.coordinates.latitude}
                  onChange={e => setTowerForm({
                    ...towerForm,
                    coordinates: { ...towerForm.coordinates, latitude: e.target.value }
                  })}
                  placeholder="33.3152"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  خط الطول (اختياري)
                </label>
                <input
                  type="number"
                  step="any"
                  className="w-full p-2 border rounded-lg"
                  value={towerForm.coordinates.longitude}
                  onChange={e => setTowerForm({
                    ...towerForm,
                    coordinates: { ...towerForm.coordinates, longitude: e.target.value }
                  })}
                  placeholder="44.3661"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              {loading ? (
                <Loader2 className="animate-spin" size={20} />
              ) : (
                <Save size={20} />
              )}
              {loading ? "جاري الإضافة..." : "إضافة البرج"}
            </button>
          </form>
        </div>

        {/* Earthlink Setup */}
        <div className={step !== "earthlink" ? "hidden" : ""}>
          <h2 className="text-2xl font-bold flex items-center gap-2 mb-6">
            <CloudDownload className="text-blue-500" />
            ربط حساب Earthlink
          </h2>
          
          <form onSubmit={handleEarthlinkSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                اسم المستخدم
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={earthlinkForm.username}
                onChange={e => setEarthlinkForm({ ...earthlinkForm, username: e.target.value })}
                placeholder="أدخل اسم المستخدم الخاص بك في Earthlink"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                كلمة المرور
              </label>
              <input
                type="password"
                required
                className="w-full p-2 border rounded-lg"
                value={earthlinkForm.password}
                onChange={e => setEarthlinkForm({ ...earthlinkForm, password: e.target.value })}
                placeholder="أدخل كلمة المرور"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                معرف الريسيلر
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-lg"
                value={earthlinkForm.resellerId}
                onChange={e => setEarthlinkForm({ ...earthlinkForm, resellerId: e.target.value })}
                placeholder="مثال: RS123456"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              {loading ? (
                <Loader2 className="animate-spin" size={20} />
              ) : (
                <CloudDownload size={20} />
              )}
              {loading ? "جاري الربط..." : "ربط الحساب واستيراد المشتركين"}
            </button>
          </form>
        </div>

        {/* Success/Error Messages */}
        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-lg">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 text-green-600 p-4 rounded-lg">
            {success}
          </div>
        )}

        {/* Help Text */}
        <div className="text-sm text-gray-500 mt-6">
          <p className="font-medium mb-2">ملاحظات:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>تأكد من صحة بيانات تسجيل الدخول الخاصة بك في Earthlink</li>
            <li>يمكنك العثور على معرف الريسيلر في لوحة تحكم Earthlink</li>
            <li>سيتم استيراد جميع المشتركين تلقائياً بعد ربط الحساب</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
