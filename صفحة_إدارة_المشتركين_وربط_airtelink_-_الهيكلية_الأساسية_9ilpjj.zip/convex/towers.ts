import { v } from "convex/values";
import { query, mutation, action, internalQuery, internalMutation } from "./_generated/server";
import { internal } from "./_generated/api";

export const listTowers = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("towers").collect();
  },
});

export const addTower = mutation({
  args: {
    name: v.string(),
    location: v.string(),
    description: v.optional(v.string()),
    coordinates: v.optional(v.object({
      latitude: v.number(),
      longitude: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("towers", {
      ...args,
      status: "active",
    });
  },
});

export const setupEarthlinkReseller = mutation({
  args: {
    towerId: v.id("towers"),
    username: v.string(),
    password: v.string(),
    resellerId: v.string(),
  },
  handler: async (ctx, args) => {
    const existingSettings = await ctx.db
      .query("earthlink_settings")
      .withIndex("by_tower", q => q.eq("towerId", args.towerId))
      .unique();

    if (existingSettings) {
      await ctx.db.patch(existingSettings._id, {
        username: args.username,
        password: args.password,
        resellerId: args.resellerId,
        isConfigured: true,
      });
      return existingSettings._id;
    }

    return await ctx.db.insert("earthlink_settings", {
      ...args,
      isConfigured: true,
      lastSync: Date.now(),
    });
  },
});

export const getEarthlinkSettings = query({
  args: {
    towerId: v.id("towers"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("earthlink_settings")
      .withIndex("by_tower", q => q.eq("towerId", args.towerId))
      .unique();
  },
});

export const _getEarthlinkSettings = internalQuery({
  args: {
    towerId: v.id("towers"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("earthlink_settings")
      .withIndex("by_tower", q => q.eq("towerId", args.towerId))
      .unique();
  },
});

export const _saveSubscriber = internalMutation({
  args: {
    towerId: v.id("towers"),
    subscriberData: v.object({
      name: v.string(),
      phone: v.string(),
      address: v.optional(v.string()),
      package: v.string(),
      status: v.union(v.literal("active"), v.literal("inactive")),
      debt: v.number(),
      earthlinkId: v.string(),
      ipAddress: v.optional(v.string()),
      macAddress: v.optional(v.string()),
      expiryDate: v.optional(v.number()),
    }),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("subscribers")
      .withIndex("by_earthlinkId", q => q.eq("earthlinkId", args.subscriberData.earthlinkId))
      .unique();

    if (existing) {
      return await ctx.db.patch(existing._id, {
        ...args.subscriberData,
        lastSync: Date.now(),
      });
    }

    return await ctx.db.insert("subscribers", {
      ...args.subscriberData,
      towerId: args.towerId,
      lastSync: Date.now(),
    });
  },
});

export const _updateLastSync = internalMutation({
  args: {
    settingsId: v.id("earthlink_settings"),
    error: v.union(v.string(), v.null()),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.settingsId, {
      lastSync: Date.now(),
      lastError: args.error || undefined,
    });
  },
});

export const importSubscribersFromEarthlink = action({
  args: {
    towerId: v.id("towers"),
  },
  handler: async (ctx, args) => {
    const settings = await ctx.runQuery(internal.towers._getEarthlinkSettings, {
      towerId: args.towerId,
    });
    
    if (!settings) {
      throw new Error("Tower settings not found");
    }

    // هذه بيانات تجريبية - يجب استبدالها بالاتصال الفعلي مع API الخاص بـ Earthlink
    const subscribers = [
      {
        name: "محمد احمد",
        phone: "07701234567",
        address: "حي الجامعة - شارع 14",
        package: "10Mbps",
        status: "active" as const,
        debt: 0,
        earthlinkId: "EL123456",
        ipAddress: "192.168.1.100",
        macAddress: "00:11:22:33:44:55",
        expiryDate: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days from now
      },
      {
        name: "علي حسين",
        phone: "07709876543",
        address: "المنصور - شارع 15",
        package: "5Mbps",
        status: "active" as const,
        debt: 25000,
        earthlinkId: "EL123457",
        ipAddress: "192.168.1.101",
        macAddress: "00:11:22:33:44:56",
        expiryDate: Date.now() + 15 * 24 * 60 * 60 * 1000, // 15 days from now
      },
    ];

    for (const subscriber of subscribers) {
      await ctx.runMutation(internal.towers._saveSubscriber, {
        towerId: args.towerId,
        subscriberData: subscriber,
      });
    }

    await ctx.runMutation(internal.towers._updateLastSync, {
      settingsId: settings._id,
      error: null,
    });

    return { imported: subscribers.length };
  },
});
