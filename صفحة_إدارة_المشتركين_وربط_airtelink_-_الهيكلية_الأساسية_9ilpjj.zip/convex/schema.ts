import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  towers: defineTable({
    name: v.string(),
    location: v.string(),
    description: v.optional(v.string()),
    status: v.union(v.literal("active"), v.literal("inactive")),
    coordinates: v.optional(v.object({
      latitude: v.number(),
      longitude: v.number(),
    })),
  }),

  earthlink_settings: defineTable({
    towerId: v.id("towers"),
    username: v.string(),
    password: v.string(),
    resellerId: v.string(),
    lastSync: v.optional(v.number()),
    lastError: v.optional(v.string()),
    isConfigured: v.boolean(),
  }).index("by_tower", ["towerId"]),
  
  subscribers: defineTable({
    towerId: v.id("towers"),
    name: v.string(),
    phone: v.string(),
    address: v.optional(v.string()),
    package: v.string(),
    status: v.union(v.literal("active"), v.literal("inactive")),
    debt: v.number(),
    earthlinkId: v.string(),
    deviceId: v.optional(v.id("network_devices")),
    ipAddress: v.optional(v.string()),
    macAddress: v.optional(v.string()),
    lastSync: v.number(),
    expiryDate: v.optional(v.number()),
    notes: v.optional(v.string()),
    coordinates: v.optional(v.object({
      latitude: v.number(),
      longitude: v.number(),
    })),
  })
    .index("by_tower", ["towerId"])
    .index("by_earthlinkId", ["earthlinkId"])
    .index("by_status", ["status"])
    .index("by_device", ["deviceId"])
    .index("by_expiry", ["expiryDate"]),

  network_devices: defineTable({
    towerId: v.id("towers"),
    name: v.string(),
    type: v.union(
      v.literal("nanostation"),
      v.literal("mikrotik"),
      v.literal("other")
    ),
    model: v.string(),
    macAddress: v.string(),
    ipAddress: v.string(),
    location: v.optional(v.string()),
    status: v.union(
      v.literal("online"),
      v.literal("offline"),
      v.literal("warning")
    ),
    lastSeen: v.number(),
    settings: v.object({
      username: v.string(),
      password: v.string(),
      ssid: v.optional(v.string()),
      channel: v.optional(v.number()),
      frequency: v.optional(v.string()),
    }),
  })
    .index("by_tower", ["towerId"])
    .index("by_mac", ["macAddress"])
    .index("by_status", ["status"]),

  notifications: defineTable({
    type: v.union(
      v.literal("subscription_expiry"),
      v.literal("payment_due"),
      v.literal("device_offline")
    ),
    message: v.string(),
    status: v.union(
      v.literal("pending"),
      v.literal("sent"),
      v.literal("failed")
    ),
    createdAt: v.number(),
    sentAt: v.optional(v.number()),
    errorMessage: v.optional(v.string()),
  }).index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
