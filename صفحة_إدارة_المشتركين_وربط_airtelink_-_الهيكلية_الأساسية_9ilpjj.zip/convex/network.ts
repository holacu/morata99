import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const listDevices = query({
  args: {
    towerId: v.optional(v.id("towers")),
  },
  handler: async (ctx, args) => {
    const baseQuery = ctx.db.query("network_devices");
    return await (args.towerId 
      ? baseQuery.withIndex("by_tower", q => q.eq("towerId", args.towerId))
      : baseQuery).collect();
  },
});

export const linkDeviceToSubscriber = mutation({
  args: {
    subscriberId: v.id("subscribers"),
    deviceInfo: v.object({
      name: v.string(),
      type: v.union(v.literal("nanostation"), v.literal("mikrotik"), v.literal("other")),
      model: v.string(),
      ipAddress: v.string(),
      location: v.optional(v.string()),
      settings: v.object({
        username: v.string(),
        password: v.string(),
        ssid: v.optional(v.string()),
        channel: v.optional(v.number()),
        frequency: v.optional(v.string()),
      }),
    }),
  },
  handler: async (ctx, args) => {
    const subscriber = await ctx.db.get(args.subscriberId);
    if (!subscriber) {
      throw new Error("المشترك غير موجود");
    }

    if (!subscriber.towerId) {
      throw new Error("المشترك غير مرتبط ببرج");
    }

    const deviceId = await ctx.db.insert("network_devices", {
      ...args.deviceInfo,
      towerId: subscriber.towerId,
      macAddress: "00:00:00:00:00:00", // سيتم تحديثه لاحقاً
      status: "online",
      lastSeen: Date.now(),
    });

    await ctx.db.patch(args.subscriberId, {
      deviceId: deviceId,
    });

    return deviceId;
  },
});

export const unlinkDeviceFromSubscriber = mutation({
  args: {
    subscriberId: v.id("subscribers"),
    deviceId: v.id("network_devices"),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.subscriberId, {
      deviceId: undefined,
    });

    await ctx.db.delete(args.deviceId);
  },
});

export const getDeviceDetails = query({
  args: {
    deviceId: v.id("network_devices"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.deviceId);
  },
});

export const updateDeviceStatus = mutation({
  args: {
    deviceId: v.id("network_devices"),
    status: v.union(
      v.literal("online"),
      v.literal("offline"),
      v.literal("warning")
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.deviceId, {
      status: args.status,
      lastSeen: Date.now(),
    });
  },
});
