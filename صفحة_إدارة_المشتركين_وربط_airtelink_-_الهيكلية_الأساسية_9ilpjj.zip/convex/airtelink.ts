import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

export const getSettings = query({
  args: {
    towerId: v.id("towers"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("earthlink_settings")
      .withIndex("by_tower", q => q.eq("towerId", args.towerId))
      .unique();
  },
});

export const listSubscribers = query({
  args: {
    towerId: v.optional(v.id("towers")),
  },
  handler: async (ctx, args) => {
    const baseQuery = ctx.db.query("subscribers");
    return await (args.towerId 
      ? baseQuery.withIndex("by_tower", q => q.eq("towerId", args.towerId))
      : baseQuery).collect();
  },
});

export const addSubscriber = mutation({
  args: {
    name: v.string(),
    phone: v.string(),
    address: v.optional(v.string()),
    package: v.string(),
    towerId: v.id("towers"),
    earthlinkId: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("subscribers", {
      ...args,
      status: "active",
      debt: 0,
      lastSync: Date.now(),
    });
  },
});

export const updateSubscriber = mutation({
  args: {
    subscriberId: v.id("subscribers"),
    update: v.object({
      name: v.optional(v.string()),
      phone: v.optional(v.string()),
      address: v.optional(v.string()),
      package: v.optional(v.string()),
      status: v.optional(v.union(v.literal("active"), v.literal("inactive"))),
      debt: v.optional(v.number()),
      notes: v.optional(v.string()),
    }),
  },
  handler: async (ctx, args) => {
    const subscriber = await ctx.db.get(args.subscriberId);
    if (!subscriber) {
      throw new Error("المشترك غير موجود");
    }
    
    await ctx.db.patch(args.subscriberId, {
      ...args.update,
      lastSync: Date.now(),
    });
  },
});

export const deleteSubscriber = mutation({
  args: {
    subscriberId: v.id("subscribers"),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.subscriberId);
  },
});
