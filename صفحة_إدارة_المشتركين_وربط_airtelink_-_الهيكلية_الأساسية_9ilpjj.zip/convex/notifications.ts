import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let notificationsQuery = ctx.db
      .query("notifications")
      .order("desc");
    
    if (args.limit) {
      return await notificationsQuery.take(args.limit);
    }
    
    return await notificationsQuery.collect();
  },
});

export const add = mutation({
  args: {
    type: v.union(
      v.literal("subscription_expiry"),
      v.literal("payment_due"),
      v.literal("device_offline")
    ),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("notifications", {
      ...args,
      status: "pending",
      createdAt: Date.now(),
    });
  },
});

export const markAsSent = mutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.notificationId, {
      status: "sent",
      sentAt: Date.now(),
    });
  },
});

export const markAsFailed = mutation({
  args: {
    notificationId: v.id("notifications"),
    error: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.notificationId, {
      status: "failed",
      errorMessage: args.error,
    });
  },
});

export const deleteNotification = mutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.notificationId);
  },
});
